# CSC221
# M3L1_Canjura
# Goal: [Gold]

"""
Author: Gabriela Canjura
holds output for program
"""

def welcomeMessage():
    
    print("Welcome to our video store.\n")

def movieName():
    
    print("Enter the movie name:")
    
def daysRented():
    
    print("Enter the number of days you are renting the movie for: ")
    
def loginMenu():
    
    print("To continue please select an option below: \n1.Login\n2.Create Account")
    
def invalidInput():
    
    print("Invalid input. \nTry again.")