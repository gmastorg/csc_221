# -*- coding: utf-8 -*-
"""
Created on Mon Oct 22 18:26:38 2018

@author: gmastorg
"""

class CustomerLogins():
    
    def __init__(self, username, password, filename):
        
        self.username = username
        self.password = password
        self.filename = filename
    

    