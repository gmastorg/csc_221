# CSC221
# M3L1_CanjuraHylton
# Goal: [Gold]

"""
class that deals with rental aspects
"""

from datetime import timedelta, date,datetime
import movies

class Rental(object):
    def __init__(self,startDate='',dueDate='',logTime='', days=3):
        self.startDate=date.today()#startDate
        self.dueDate=self.startDate+(timedelta(days=3))
        self.logTime=datetime.now().time()
        self.days=days
    

    def getTimeStamp(self):
        return self.logTime

    def calcTimeSpan(self):
        #Rent Time
        self.rentTime=datetime.now().time()
        #Return Time
        self.returnTime=datetime.now().time()
        #TimeSpan
        return self.returnTime-self.rentTime
    
    def __str__(self):
        t=movies.Movie()
        text=("Time Stamp: "+str(self.logTime))
        text+=("\nRate: "+str(t.rate)+"\nStart Date: "+str(self.startDate))
        return text
