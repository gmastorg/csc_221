import display
import csv
import login as l
import validateInput as v
import customer as c
from customer import Customer
from movies import Movie
from rental import Rental

from store import Store

########################LOGIN############################################
def login():
    maxOption = 2
    pass
##    print(display.welcomeMessage())
##    choice = input(display.loginMenu())
##    while v.validateNull(choice) == False:#validates input
##        choice = input(display.loginMenu())
##    while v.validateText(choice, maxOption) == False:
##        display.invalidInput()
##        choice = input(display.loginMenu())
##    decision = int(choice)# uses user input to login or create account       
##    l.loginDecision(decision)
########################################################################
def createHeader():
    s=Store()
    header=str(s)
    print(header)#Needs alignment work.
    return s,header
########################CHOICE############################################
def mainChoice():
    menu="1. RENT\n 2. RETURN\n 3. EXIT\n"
 
    print("\nChoose an option:\n\n",menu,)
    option=input("Enter '1', '2', or '3': ")
    if option=='1':
        getRentals()
    elif option=='2':
        pass
    elif option=='3':
        exit
    else:
        print("Enter a valid choice.")
######################GET RENTALS#######################################
def getRentals():
    movieList,movieDetails=importMovies()
    movies,rates=selectMovies(movieList,movieDetails)
    cost,grandTotal=checkOut(movies,rates)
    c.Customer.getPayment()
    makeReceipt(movies, rates, cost, grandTotal)
########################GET RETURNS#######################################
def getReturns():
    pass
########################GENRECHOICES#######################################
def getGenre():
    m=Movie()
    genre=m.getMovieGenre()
    return genre
########################FORMATCHOICE#####################################
def getFormat():
    m=Movie()
    Format,rate=m.getMovieFormat()
    return Format,rate
#####################MOVIE IMPORT############################################   
def importMovies():
    movieList = [] 
    allMovies = []#a list of movie objects
    movieDetails=[]#a list of all movie tuples
    header=True
    with open("movies.csv") as file:
        inputFile = csv.reader(file)
        if header:
            next(inputFile)
        count=1
        for r in inputFile:
            title=r[0]
            genre=r[1]
            description = r[0]
            year=r[7]
            m=Movie(title,description,year)
            movieObject=Movie(title,genre,description,year)
 #           print(movieObject)#prints address
            movieTuple=(title,genre,m.description,year)
 #           print(movieTuple) #prints perfectly
            movieList.append(title)#appends titles to list
            #WHEN DONE DELETE MOVIEOBJECTS 
            allMovies.append(movieObject) #COMPLETE LIST OF OBJECTS OF MOVIES
            movieDetails.append(movieTuple)
            count+=1
    return movieList,movieDetails

############################MOVIE SELECTION##################################
def selectMovies(movieList,movieDetails):
    menu=("1. LIST MOVIES\n 2. SEARCH MOVIES")
    print("\nChoose an option:\n\n",menu,)
    option=input("Enter '1' or '2': ")
    if option=='1':
        listMovies(movieList,movieDetails)
    elif option=='2':
        movies,rates=searchMovies(movieList,movieDetails)       
    else:
        print("Enter a valid choice.")
    return movies, rates


def listMovies(movieList,movieDetails):
    count=1
    for movie in movieList:
        print(count,movie)
        count+=1
    choice=input("Would you like to add a movie? (y/n)\n")
    if choice=='y':
        searchMovies(movieList,movieDetails)
    else:
        print("Returning to main menu....")
        mainChoice()

        
def searchMovies(movieList,movieDetails):
    movies=[]
    rates=[]
    childrens=[]
    newReleases=[]
    regular=[]
    for row in movieDetails:
        if row[1]=='Animation':
             childrens.append(row[0])
        if row[3]=='2011':
            newReleases.append(row[0])
        else:
            regular.append(row[0])
    again='y'
    while again=='y':
        genre=getGenre()
        if genre=='Regular':
            show=regular
        elif genre=='Children':
            show=childrens
        else:
            show=newReleases

        search=input("Enter a movie title: ")
        if search in show:
            print(search, "is an available movie.")
        elif search not in show and search in movieList:
            print(search,"is an available movie, but not in "\
                      "your selected genre.")
        else:
            print(search, "is not an available movie.")
            selectMovies(movieList,allMovies)
            
        choice=input("Add movie to your queue? (y/n)\n")
        choice=choice.lower()
        Format,rate=getFormat()
        if choice=='y':
            m=Movie()
            title=search
            m.genre=genre
            m.Format=Format
            m.rate=rate
            year=row[3]
            m=Movie(title, m.description, year, m.genre,m.Format,m.rate)
            print(m)
            movies.append(m)
            r=Rental()
            r=Rental(r.startDate,r.dueDate,m.rate)#obtains and displays rental information per movie
            rates.append(r)
            again=input("Add another movie? (y/n)\n")
            again=again.lower()
    return movies, rates
#############################calCharges#####################################
def checkOut(movies, rates):
    """uses list of movie objects and list of rental objects to display movies rented as well as the total cost"""
    total = 0
    days=3
    purchaseHeader=("RENTAL\tFORMAT\tDAILY RATE\n")
    line=('-'*len(purchaseHeader))
    
    print(purchaseHeader,line)
    
    for item in movies:

        print(item.title+"\t"+item.Format+"\t"+str(item.rate))
        cost = float(item.rate)*days
        total += cost
    tax = 1.05 # give 105% of the total basically same as (total*.05)+total
    total = total*tax 
    
    print("\nTotal: $"+'{0:.2f}'.format(total)+"\n")  
    grandTotal='{0:.2f}'.format(total)
    return cost, grandTotal
    
###########################RECEIPT########################################
def makeReceipt(movies,rates,cost,grandTotal):
    s,header=createHeader()
    '''writes data to receipit in txt file'''
    outfile=open("receipt.txt",'w')#Creates a receipt file to hold rental items.
    spacing=('\n'+'\n'+'\n')
    outfile.write(header+'\n'+spacing)#str(getTransactionTime(s))+spacing)
    tax="5%"
    head='{:<20}'*3
    outfile.write(head.format("MOVIE RENTAL","FORMAT","DAILY RATE")+'\n')
    outfile.write("-"*50+"\n")
    var='{:<20}'
    for item in movies:
        item.title=var.format(item.title)
        item.format=var.format(item.Format)
        item.rate=var.format(str(item.rate))
        strCost='$'+str(cost)
        strTotal='$'+str(grandTotal)
        outfile.write(item.title+item.format+str(item.rate)+'\n')
    outfile.write(spacing*2)
    space='{:<60}'

    outfile.write((var.format('Min. 3 Day SubTotal: '))+(space.format(strCost))+'\n')
    outfile.write((var.format('Tax: '))+(space.format(tax))+'\n')
    outfile.write((var.format('Grand Total: '))+(space.format(strTotal))+'\n')
    outfile.write((spacing*2))    
    
    outfile.write(s.message)

    outfile.close()
    print("Your receipt is ready.")
    customerRental(movies,rates,cost,grandTotal)
###########################MAIN###########################################

def main():
    login()
    createHeader()
    mainChoice()

#########################CUSTOMEROBJECT########################################
def customerRental(movies,rates,cost,grandTotal):
 #   c=Customer()
    c=Customer('Marie','Hylton','123','ftb','nc','28307')
    print(c) #prints str(c)
 #   print(str(c)) #prints str(c)
    
    for x in movies:
        a=Rental()
        e=Rental()
        b=()
        d=[]
        timeStamp=a.logTime
 #       name=c.getCustomerName()
        title=x.title
        Format=x.format
        rate=x.rate
        start=a.startDate
 #       end=a.dueDate           
        b=(a.getTimeStamp(),c.getCustomerName(),x.title,rate,a.startDate)
        d=[timeStamp,c.getCustomerName(),title,rate,start]
        a=Rental(timeStamp,x.title,x.rate,start)#doesn't give title or rate
        e=Rental(d)
        print(e)
        print(a)
        print(b)
        print(d)
        print(c)
     




main()
