# CSC221
# M3L1_CanjuraHylton
# Goal: [Gold]

"""
class for username, login and filename for customer
"""

class CustomerLogins():
    
    def __init__(self, username, password, filename):
        
        self.username = username
        self.password = password
        self.filename = filename
    

    