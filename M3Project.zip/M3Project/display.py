# CSC221
# M3L1_CanjuraHylton
# Goal: [Gold]

"""
holds output for program
"""

def welcomeMessage():
    
    welcome = "Welcome to our RedFox Rental Store.\n"
    
    return welcome

def movieName():
    
    movieName = "Enter the movie name:"
    
    return movieName   
    
def loginMenu():
    
    loginMenu = "To continue please select an option below: \n1.Login\n2.Create Account\n"
    
    return loginMenu
    
def invalidInput():
    
    invalidInput = "Invalid input. \nTry again."
    
    return invalidInput
